function dy = ftest(t,y)
lambda = -.5;

dy = zeros(1,1);
dy(1) = lambda*y(1);
