eps = 1; t = 2;
while t>1
    eps = eps/2; t=1+eps;
end
eps = 2*eps;
clear t;