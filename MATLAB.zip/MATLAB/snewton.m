function [Z, ind] = snewton(f, tm, um, method, nmax, tol)
% Input: Funktion f, Startwert (t_m, Z^(0)_m), Methode, maximale Anzahl der Iterationen, Toleranz tol
% Output: Näherungswert Z, oder Ausgabe Fehler

% Schritt 0: Initialisieren
if nargin < 5
	nmax = 50; tol = 1e-4;
elseif nargin < 5
	nmax = 50; tol = 1e-4;
else
	tol = 1e-4;
end

method = sprintf('%s.mat',method);
load(method);
A = config.A; b = config.b; c=config.c;
s = config.s; n = length(um);
kry = 1e-3; h = 1e-2; eins = ones(s,1);
Z(:,1)=zeros(s,1);
	
% Schritt 1
for l=1:nmax
	% Schritt 2: Schritte 3-6
		%Schritt 3
        dF = njacob(f,tm,um);
		F = arrayfun(f,tm+c.*h,Z(l)+kron(eins,um));
		LHS = eye(s*n) - h*kron(A,dF);
		RHS = -Z(:,l) + h*(kron(A,eye(n)))*F;
		dZ = linsolve(LHS,RHS);
		% Schritt 4
		l = l+1;
		% Schritt 5
		Z(:,l) = Z(:,l-1) + dZ;
		% Schritt 6:
		if l > 3
			theta=norm(Z(:,l)-Z(:,l-1))/norm(Z(:,l-1)-Z(:,l-2));
			kappa = (theta)/(1-theta)*norm(Z(:,l)-Z(:,l-1));
			if kappa <= kry*tol
				ind =1; return
			end
		end
end