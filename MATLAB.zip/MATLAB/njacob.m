function dF = njacob(f,tm,um)
n = length(um);
E = speye(n);
for j=1:n
	delta = sqrt(eps)*max([1, abs(um(j))]);
	dF(:,j) = (f(tm,um+delta*E(:,j)) - f(tm,um))/delta;
end