function [t u] = implicitRK(f,t0,y0,te, method, nmax, h, tol)
% Schritt 0: Initialisieren
if nargin < 5
	load euler.mat;
	nmax = 50; tol = 1e-4;
elseif nargin < 6
	nmax = 50; tol = 1e-4;
else
	tol = 1e-4;
end
method = sprintf('%s.mat',method);
load(method);

A = config.A; b = config.b; c=config.c;
s = config.s; n = length(y0);
eins = ones(n,1); U(1,:)=zeros(1,n);
u(:,1)=y0; t(1)=t0;
h=(te-t0)/nmax;

m=1; exit=false;
while t(end)<=te
	Z = snewton(f, t(m), u(m), method);
	U = Z(:,end) + kron(eins,u(:,m)); F = arrayfun(f,t(m)+c.*h,U);
	m=m+1;
    u(:,m) = u(:,m-1) + h*kron(b',eye(n))*F; t(m)=t(m-1)+h;
end